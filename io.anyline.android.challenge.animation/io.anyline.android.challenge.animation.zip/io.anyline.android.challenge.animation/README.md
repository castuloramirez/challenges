![](https://i.imgur.com/968P29U.png)



This is a small Android App in which you rebuilt the Kitt animations from Knight Rider with Views. In the best case including UI elements (effects, speed etc).

### Install Android Developer Studio

https://www.google.com/search?client=ubuntu&channel=fs&q=android+developer+studio&ie=utf-8&oe=utf-8

### Run the Project

Now you can run the project.

![](https://i.imgur.com/GGPvs3P.png)


